export const Jyoti = ()=>{
  return (
    <>
      <h1>test1</h1>
    </>
  )
}

export const Jyoti2 = ()=>{
  return (
    <>
      <h1>test2</h1>
    </>
  )
}

// export default Jyoti2
// export {Jyoti, Jyoti2}