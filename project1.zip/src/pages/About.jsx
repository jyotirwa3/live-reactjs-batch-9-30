import axios from "axios"
import { useEffect, useState } from "react"

const About = () => {
  const [products, setProduct] = useState([])

  async function showApi() {
    await axios.get('https://684baaa1ed2578be881c0ca9.mockapi.io/api/products')
      .then((res) => {
        setProduct(res.data)
      })
      .catch((err))
      console.log('err: ', err);
  }

  useEffect(() => {
    showApi()
  }, [])
  return (
    <>
      {/* {console.log(products)} */}
      <table className="table table-striped table-hover table-success container my-5">
        <thead>
          <tr>
            <th>#</th>
            <th>category</th>
            <th>name</th>
            <th>price</th>
            <th>desc</th>
            <th>date</th>
          </tr>
        </thead>
        <tbody>
          {
            products.map(({category,p_name,p_price,p_desc,createdAt},index)=>{
              return (
                <tr key={index}>
                  <td>{index+1}</td>
                  <td>{category}</td>
                  <td>{p_name}</td>
                  <td>{p_price}</td>
                  <td>{p_desc}</td>
                  <td>{new Date(createdAt).toDateString()}</td>
                </tr>
              )
            })
          }
        </tbody>
      </table>
    </>
  )
}

// const date = new Date()
// console.log(date.toLocaleDateString())

const date = new Date('2025-06-12T15:01:19.597Z')
console.log(date.toDateString())

export default About
