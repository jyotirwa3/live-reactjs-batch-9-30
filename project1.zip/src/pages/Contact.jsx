const Contact = () => {
  return (
    <>
        <h1>Contact Page</h1>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Sapiente illum consequatur vero omnis, impedit qui voluptate, dolorum alias nam explicabo necessitatibus sequi? Repellendus laboriosam velit fugiat! Incidunt blanditiis rem necessitatibus!</p>
    </>
  )
}

export default Contact
