import axios from "axios"
import { useForm } from "react-hook-form"

const Home = () => {

  const { register, handleSubmit, reset } = useForm()

  async function product(data){
    // const res = await axios.post('https://684baaa1ed2578be881c0ca9.mockapi.io/api/products',data)
    // console.log(res.data)
    const newData = {...data,createdAt:new Date()}
    // console.log({data,createdAt:new Date()})
    
    await axios.post('https://684baaa1ed2578be881c0ca9.mockapi.io/api/products',newData)
    .then((res)=>{
      console.log(res.data)
      alert("your product has been inserted!")
      reset()
    })
    .catch((err)=>console.log(err))
  }
  return (
    <>
      <form action="" onSubmit={handleSubmit(product)} className="col-lg-6 mx-auto my-5 p-5 shadow">
        <div className="mt-4">
          <select className="form-select" {...register('category')}>
            <option value="" disabled selected>--select category--</option>
            <option value="Electronics">Electronics</option>
            <option value="Cloth">Cloth</option>
            <option value="Toy">Toy</option>
            <option value="Other">Other</option>
          </select>
        </div>
        <div className="mt-4">
          <input type="text" {...register('p_name')} className="form-control" placeholder="enter product name" />
        </div>
        <div className="mt-4">
          <input type="number" {...register('p_price')} className="form-control" placeholder="enter product price" />
        </div>
        <div className="mt-4">
          <textarea {...register('p_desc')} className="form-control" placeholder="enter description"></textarea>
        </div>
        <div className="mt-4">
          <button className="btn btn-success">submit</button>
        </div>
      </form>
    </>
  )
}

export default Home
