
const PageNotFound = () => {
  return (
    <>
      <img src="https://media.geeksforgeeks.org/wp-content/uploads/20230802153215/Error-404.png" alt="" width="100%" height="100%" />
    </>
  )
}

export default PageNotFound
